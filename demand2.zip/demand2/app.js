const puppeteer = require("puppeteer");
const cheerio = require("cheerio");
const fs = require("fs");

const config = require('./config');

const resultDir = __dirname + '/result';
const resultFileName = resultDir+`/result${config.version}.txt`;
const listDir = __dirname + "/links";
const listFile = listDir + "/linkList.csv"
const baseUrl = 'https://www.baidu.com/s?wd=';


const str2Num = function(numStr) {
    console.log(numStr);
    let numStrArr = numStr.split(','), 
        sum = 0;
    for(let i = numStrArr.length - 1, multiple = 1; i>=0; i--) {
        let num = parseInt(numStrArr[i]) * multiple;
        sum += num;
        multiple = multiple*1000
    }
    return sum;
}

const readLinkList = function(filename){
    let fileContent = fs.readFileSync(filename,"utf-8");
    // console.log(fileContent);
    let contentList = fileContent.split('\n');
    let linkList = contentList.map(function(item){
        let arr = item.split(" ");
        let link = arr[arr.length-1];
        if(link.slice(0,36) == "https://buy.cloud.tencent.com/domain"){
            link = 'https://buy.cloud.tencent.com/domain';
        }
        return link
    })
    linkList.splice(0,1)
    return linkList;
}

const main = async () => {
    const browser = await puppeteer.launch({
        executablePath:'/private/var/folders/nj/vhtqy9k527l95q_yvjpyv7ww0000gn/T/AppTranslocation/6B38B17E-B528-4651-AD79-67CFF25C13EE/d/Chromium.app/Contents/MacOS/Chromium'
    });
    const page = await browser.newPage();
    const linklist = readLinkList(listFile);

    for(let i in linklist){
        await page.goto(baseUrl+linklist[i]);
        const content = await page.content();
    
        const $ = cheerio.load(content, { decodeEntities: false });
        let numText = $("#container").find('.head_nums_cont_inner .nums_text').text();
        let patten = /约(.*?)个/
        let num = str2Num(patten.exec(numText)[1]);
        console.log(`${linklist[i]}： ${num}`)

        let isInclude = num !== 0 ? 1 : 0;
        let contentString = linklist[i] + " " + isInclude + "\n"; 
        fs.appendFileSync(resultFileName,contentString);
    }
    await browser.close();
};

main();
